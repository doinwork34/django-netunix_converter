from django.apps import AppConfig


class NetunixConfig(AppConfig):
    name = 'netunix'
